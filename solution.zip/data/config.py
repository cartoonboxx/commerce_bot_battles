Token = '7826614546:AAGG3HIa-iP4ifNbdYaObcjarnf8IRdm-Lw'

# 794764771
admins = [794764771]

bot_name = 'vndfkjnkjdfgbknvds_bot'